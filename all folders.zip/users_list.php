<?php
session_start();
$conn = new mysqli("localhost", "root", "", "sportsmate_db");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$current_user = $_SESSION['user_id'];

// Handle actions
if (isset($_GET['add'])) {
    $receiver = $_GET['add'];
    $conn->query("INSERT INTO friends (sender_id, receiver_id, status) VALUES ($current_user, $receiver, 'pending')");
    $conn->query("INSERT INTO notifications (user_id, message) VALUES ($receiver, 'You received a friend request')");
}


if (isset($_GET['accept'])) {
    $sender = $_GET['accept'];
    $conn->query("UPDATE friends SET status='accepted' WHERE sender_id=$sender AND receiver_id=$current_user");
    $conn->query("INSERT INTO notifications (user_id, message) VALUES ($sender, 'Your friend request was accepted')");
}
if (isset($_GET['remove'])) {
    $friend = $_GET['remove'];
    $conn->query("DELETE FROM friends WHERE (sender_id=$current_user AND receiver_id=$friend) OR (sender_id=$friend AND receiver_id=$current_user)");
}

$users = $conn->query("SELECT * FROM users WHERE id != $current_user");
?>

<!DOCTYPE html>
<html>
<head>
<title>SportsMate | Friends</title>
<style>
body { background:black; color:white; padding:20px; font-family:Arial; }
.box { background:#1e1e1e; padding:15px; margin:10px 0; border-radius:10px; }
.btn { background:#00eaff; color:black; padding:6px 10px; border-radius:6px; text-decoration:none; margin-left:10px; }
</style>
</head>
<body>

<h2>Connect with Players 🤝</h2>

<?php while($user = $users->fetch_assoc()) { 
    $uid = $user['id'];

    // Get friendship status
    $friendCheck = $conn->query("
        SELECT * FROM friends 
        WHERE (sender_id=$current_user AND receiver_id=$uid) 
        OR (sender_id=$uid AND receiver_id=$current_user)
    ")->fetch_assoc();

    echo "<div class='box'><strong>{$user['name']}</strong>";

    if (!$friendCheck) {
        echo "<a href='users_list.php?add=$uid' class='btn'>Add Friend</a>";
    } 
    else if ($friendCheck['status'] == "pending" && $friendCheck['receiver_id'] == $current_user) {
        echo "<span style='color:yellow;'>Pending Request</span>";
        echo "<a href='users_list.php?accept=$uid' class='btn'>Accept</a>";
    } 
    else if ($friendCheck['status'] == "pending") {
        echo "<span style='color:yellow;'>Request Sent</span>";
    }
    else {
        echo "<span style='color:#00ff7f;'>Friends ✔</span>";
        echo "<a href='users_list.php?remove=$uid' class='btn' style='background:red;'>Remove</a>";
    }

    echo "</div>";
} ?>

<a style="color:#00eaff; display:block; margin-top:20px;" href="dashboard.php">⬅ Back</a>

</body>
</html>
