<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>SportsMate</title>
<script src="https://cdn.tailwindcss.com"></script>

<style>
:root{
  --neon:#06f6c8;
  --dark:#0b0f14;
}
body{
  background:linear-gradient(180deg,#07080a 0%, #0f1724 100%);
  color:#e6eef6;
  font-family:Inter,ui-sans-serif;
}
.card{
  background:rgba(255,255,255,0.03);
  border-radius:14px;
  padding:24px;
  box-shadow:0 6px 24px rgba(2,6,23,0.6);
}
.btn-primary{
  background:linear-gradient(90deg,var(--neon),#07b3ff);
  color:#052023;
  font-weight:700;
  padding:.7rem 1rem;
  border-radius:10px;
  text-decoration:none;
  display:inline-block;
}
</style>
</head>

<body>

<!-- TOP NAVBAR -->
<header class="py-4 px-6 flex items-center justify-between">
  <div class="flex items-center gap-4">
    <div style="
      width:48px;height:48px;
      background:linear-gradient(45deg,var(--neon),#07b3ff);
      border-radius:10px;
      display:flex;align-items:center;justify-content:center;
      font-weight:bold;color:#052023">SM</div>

    <div>
      <h1 style="margin:0;font-size:1.25rem;font-weight:700">SportsMate</h1>
      <div style="font-size:0.8rem;color:#9fb4c6">Connect • Play • Learn</div>
    </div>
  </div>

  <div>
    <?php if (!isset($_SESSION['user_id'])): ?>
      <a href="login.php" class="btn-primary">Login</a>
    <?php else: ?>
      <a href="dashboard.php" class="btn-primary">Dashboard</a>
    <?php endif; ?>
  </div>
</header>


<!-- HERO SECTION -->
<main class="container mx-auto mt-10 px-8">
  <div class="card max-w-3xl mx-auto text-center">
    <h2 class="text-3xl font-bold mb-3">Welcome to SportsMate</h2>
    <p class="text-gray-400 mb-6">
      Your all-in-one platform to find teammates, join sports events,
      and explore training resources — with a modern, clean interface.
    </p>

    <?php if (!isset($_SESSION['user_id'])): ?>
      <a href="login.php" class="btn-primary">Get Started</a>
    <?php else: ?>
      <a href="dashboard.php" class="btn-primary">Explore Dashboard</a>
    <?php endif; ?>
  </div>
</main>


<!-- FEATURES SECTION -->
<section class="container mx-auto px-8 mt-10 grid md:grid-cols-3 gap-6">

  <div class="card text-center">
    <h3 class="font-bold text-xl mb-2">⚽ All Sports</h3>
    <p class="text-gray-400">Browse and join events for any sport you love.</p>
  </div>

  <div class="card text-center">
    <h3 class="font-bold text-xl mb-2">📅 Create Events</h3>
    <p class="text-gray-400">Host your own sports events and invite players.</p>
  </div>

  <div class="card text-center">
    <h3 class="font-bold text-xl mb-2">💬 Chat System</h3>
    <p class="text-gray-400">Message teammates instantly with a smooth chat UI.</p>
  </div>

</section>

</body>
</html>
