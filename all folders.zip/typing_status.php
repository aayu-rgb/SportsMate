<?php
session_start();
$conn = new mysqli("localhost", "root", "", "sportsmate_db");

$sender = $_SESSION['user_id'];
$receiver = $_POST['receiver'];

$conn->query("UPDATE users SET typing_to=$receiver WHERE id=$sender");
echo "ok";
?>
