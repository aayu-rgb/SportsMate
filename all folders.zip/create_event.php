<?php
session_start();
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

/**
 * Fetch sports for the select box.
 * The code assumes you have a table `sports_data` with columns `id` and `sport`.
 * If your table name or columns are different, update the query below.
 */
$sports = [];
$sports_sql = "SELECT id, sport FROM sports_data ORDER BY sport ASC";
if ($res = $conn->query($sports_sql)) {
    while ($r = $res->fetch_assoc()) {
        $sports[] = $r;
    }
    $res->free();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Basic validation & sanitize
    $event_title = trim($_POST['event_title'] ?? '');
    $sport_id = intval($_POST['sport'] ?? 0);
    $event_date = trim($_POST['event_date'] ?? '');
    $event_location = trim($_POST['event_location'] ?? '');

    if ($event_title === '' || $sport_id <= 0 || $event_date === '' || $event_location === '') {
        echo "<script>alert('Please fill all fields.'); history.back();</script>";
        exit;
    }

    // Insert event using prepared statement
    $insertEventSql = "INSERT INTO events (user_id, event_title, sport_id, event_date, event_location, created_at) VALUES (?, ?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($insertEventSql);
    if (!$stmt) {
        echo "<script>alert('Database error.'); history.back();</script>";
        exit;
    }
    $stmt->bind_param("isiss", $user_id, $event_title, $sport_id, $event_date, $event_location);

    if ($stmt->execute()) {
        $event_id = $stmt->insert_id;
        $stmt->close();

        // Prepare notification message (Style C)
        // We'll fetch sport name for a nicer message
        $sport_name = "";
        $sportStmt = $conn->prepare("SELECT sport FROM sports_data WHERE id = ?");
        if ($sportStmt) {
            $sportStmt->bind_param("i", $sport_id);
            $sportStmt->execute();
            $sportStmt->bind_result($sport_name);
            $sportStmt->fetch();
            $sportStmt->close();
        }

        $displayDate = date("F j, Y", strtotime($event_date));
        $notifMessage = "⚽ New Event Created! {$event_title} on {$displayDate}";

        // Insert a notification for EVERY user (Option B)
        // Use a prepared statement for inserting notifications
        $notifInsertSql = "INSERT INTO notifications (user_id, message, seen, created_at) VALUES (?, ?, 0, NOW())";
        $notifStmt = $conn->prepare($notifInsertSql);

        if ($notifStmt) {
            // Get all user ids
            $allUsersRes = $conn->query("SELECT id FROM users");
            if ($allUsersRes && $allUsersRes->num_rows > 0) {
                while ($u = $allUsersRes->fetch_assoc()) {
                    $targetUid = intval($u['id']);
                    // bind and execute per user
                    $notifStmt->bind_param("is", $targetUid, $notifMessage);
                    $notifStmt->execute();
                }
                $allUsersRes->free();
            }
            $notifStmt->close();
        } else {
            // if preparing notification fails, continue — event is created
            error_log("Notification prepare failed: " . $conn->error);
        }

        // Redirect back to dashboard with success
        echo "<script>alert('Event created successfully!'); window.location='dashboard.php';</script>";
        exit;
    } else {
        $err = $stmt->error;
        $stmt->close();
        echo "<script>alert('Error creating event: " . htmlspecialchars($err) . "'); history.back();</script>";
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Create Event - SportsMate</title>
<link rel="stylesheet" href="style.css">
<style>
/* small inline styles to ensure form looks ok if style.css not yet included */
.form-card { max-width:520px; margin:30px auto; padding:20px; border-radius:12px; background:#0f1720; box-shadow:0 10px 30px rgba(0,0,0,.6); }
.form-card h2 { margin:0 0 12px 0; color:#00eaff; }
.input, select { width:100%; padding:12px; margin:8px 0; border-radius:10px; border:1px solid rgba(255,255,255,0.06); background:#07111a; color:#e6eef6; }
.btn { display:inline-block; background:linear-gradient(90deg,#00eaff,#06f6c8); color:#042226; padding:10px 14px; border-radius:10px; border:none; cursor:pointer; font-weight:700; }
.small { color:#9fb4c6; font-size:.9rem; }
</style>
</head>
<body>

<div class="form-card">
    <h2>Create Event</h2>

    <form method="POST" action="">
        <label class="small">Event Title</label>
        <input class="input" type="text" name="event_title" required>

        <label class="small">Sport</label>
        <select name="sport" class="input" required>
            <option value="">-- Select sport --</option>
            <?php foreach ($sports as $s): ?>
                <option value="<?= htmlspecialchars($s['id']) ?>"><?= htmlspecialchars($s['sport']) ?></option>
            <?php endforeach; ?>
        </select>

        <label class="small">Date</label>
        <input class="input" type="date" name="event_date" required>

        <label class="small">Location</label>
        <input class="input" type="text" name="event_location" required>

        <div style="margin-top:12px;">
            <button class="btn" type="submit">Create Event</button>
            <a href="dashboard.php" class="btn" style="background:transparent;border:1px solid rgba(255,255,255,0.06);color:#e6eef6;margin-left:8px;text-decoration:none;">Cancel</a>
        </div>
    </form>
</div>

</body>
</html>
