<?php
session_start();

// show loading page ONLY on first visit
if (!isset($_SESSION["show_loading"])) {
    $_SESSION["show_loading"] = true;
    header("Location: loading.php");
    exit();
}
?>

<?php include "home.php"; ?>
