<?php
session_start();
$conn = new mysqli("localhost", "root", "", "sportsmate_db");

$receiver = $_SESSION['user_id'];
$sender = $_GET['receiver'];

$check = $conn->query("SELECT typing_to FROM users WHERE id=$sender")->fetch_assoc();

if ($check['typing_to'] == $receiver) {
    echo "Typing...";
} else {
    echo "";
}
?>
