<?php
// send_message.php
// Purpose: insert a message and create a notification for the receiver (Style C)

// Start session and DB
session_start();
include "config.php"; // must set $conn (mysqli) inside config.php

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit;
}

// Expect POST data: receiver, message
$sender = intval($_SESSION['user_id']);
$receiver = isset($_POST['receiver']) ? intval($_POST['receiver']) : 0;
$message = isset($_POST['message']) ? trim($_POST['message']) : '';

if ($receiver <= 0 || $message === '') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid input']);
    exit;
}

// Insert message into messages table
// expects messages table with columns: id, sender_id, receiver_id, message, timestamp, status (optional)
$insertMsgSql = "INSERT INTO messages (sender_id, receiver_id, message, status, timestamp) VALUES (?, ?, ?, 'sent', NOW())";
$stmt = $conn->prepare($insertMsgSql);
if (!$stmt) {
    echo json_encode(['status' => 'error', 'message' => 'DB prepare failed: '.$conn->error]);
    exit;
}
$stmt->bind_param("iis", $sender, $receiver, $message);

if ($stmt->execute()) {
    $message_id = $stmt->insert_id;
    $stmt->close();

    // Create a short notification for receiver (Style C)
    // Notification text example: "💬 New Message!"
    $notifText = "💬 New Message!";

    // Insert notification: expects notifications table (id, user_id, message, seen, created_at)
    $notifSql = "INSERT INTO notifications (user_id, message, seen, created_at) VALUES (?, ?, 0, NOW())";
    $nstmt = $conn->prepare($notifSql);
    if ($nstmt) {
        $nstmt->bind_param("is", $receiver, $notifText);
        $nstmt->execute();
        $nstmt->close();
    } else {
        // Non-fatal: continue if notifications insert fails
        error_log("Notif prepare failed: ".$conn->error);
    }

    // Return success
    echo json_encode(['status' => 'ok', 'message' => 'Message sent', 'message_id' => $message_id]);
    exit;
} else {
    $err = $stmt->error;
    $stmt->close();
    echo json_encode(['status' => 'error', 'message' => 'Insert failed: '.$err]);
    exit;
}
