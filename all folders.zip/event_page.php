<?php
session_start();
$conn = new mysqli("localhost", "root", "", "sportsmate_db");

if (!isset($_GET['id'])) {
    die("Invalid event.");
}

$id = intval($_GET['id']);
$event = $conn->query("SELECT * FROM events WHERE id=$id")->fetch_assoc();

// Handle Join
if (isset($_POST['join'])) {
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit;
    }
    $uid = $_SESSION['user_id'];
    $conn->query("INSERT INTO event_participants (event_id, user_id) VALUES ($id, $uid)");
    $joined = true;
}

// Check if already joined
$joinedCheck = false;
if (isset($_SESSION['user_id'])) {
    $uid = $_SESSION['user_id'];
    $check = $conn->query("SELECT * FROM event_participants WHERE event_id=$id AND user_id=$uid");
    if ($check->num_rows > 0) $joinedCheck = true;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title><?= $event['title'] ?></title>
    <style>
        body {
            background: #0d0d0d;
            color: white;
            font-family: Arial, sans-serif;
            padding: 20px;
        }
        .box {
            background:#1e1e1e;
            padding: 20px;
            border-radius: 15px;
            max-width: 500px;
            margin: auto;
            text-align: center;
        }
        button {
            background: #00eaff;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 18px;
            margin-top: 20px;
        }
        .disabled {
            background: gray;
            cursor: not-allowed;
        }
        a {
            text-decoration: none;
            color:#00eaff;
            display: block;
            margin-top:20px;
        }
    </style>
</head>
<body>

<div class="box">
    <h2><?= $event['title'] ?></h2>
<a href="invite_friends.php?event=<?= $id ?>" style="color:#00eaff;">🤝 Invite Friends</a>

    <p><strong>Sport:</strong> <?= $event['sport'] ?></p>
    <p><strong>Location:</strong> <?= $event['location'] ?></p>
    <p><strong>Date:</strong> <?= $event['event_date'] ?></p>

    <?php if (isset($joined) || $joinedCheck): ?>
        <button class="disabled">✔ You Joined This Event</button>
    <?php else: ?>
        <form method="post">
            <button type="submit" name="join">Join Event</button>
        </form>
    <?php endif; ?>

    <a href="dashboard.php">⬅ Back</a>
</div>

</body>
</html>
