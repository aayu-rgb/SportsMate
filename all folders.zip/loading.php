<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SportsMate Loading...</title>
    <style>
        body {
            background: #000;
            color: #00bcd4;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            font-size: 28px;
        }

        .loader {
            animation: fade 1s infinite alternate;
        }

        @keyframes fade {
            from { opacity: 0.3; }
            to { opacity: 1; }
        }
    </style>

    <script>
        // Redirect after loading animation
        setTimeout(function() {
            window.location.href = "index.php"; 
        }, 2500);
    </script>
</head>
<body>

<div class="loader">
    ⚽ SportsMate Loading...
</div>

</body>
</html>
