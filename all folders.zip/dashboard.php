<?php
session_start();
require "config.php";

// If user is not logged in → send to home
if (!isset($_SESSION['user_id'])) {
    header("Location: home.php");
    exit();
}

$userName = $_SESSION['user_name'];

// SPORTS (static array)
$sports = [
    ["⚽", "Football"],
    ["🏀", "Basketball"],
    ["🎾", "Tennis"],
    ["🏏", "Cricket"],
    ["🏐", "Volleyball"],
    ["🏓", "Table Tennis"],
    ["🥊", "Boxing"],
    ["🏃", "Running"],
    ["🏊", "Swimming"],
    ["⚡", "Badminton"]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Dashboard - SportsMate</title>

<style>
:root{
  --neon:#06f6c8;
}

body {
    margin:0;
    background:linear-gradient(180deg,#07080a 0%, #0f1724 100%);
    color:white;
    font-family:Arial, sans-serif;
}

/* NAVBAR */
.navbar {
    background:#0e1220;
    padding:18px 25px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    border-bottom:1px solid rgba(255,255,255,0.05);
    box-shadow:0 4px 20px rgba(0,0,0,0.4);
}

.nav-left h1 {
    margin:0;
    font-size:22px;
    font-weight:700;
    color:var(--neon);
}

.nav-right a {
    text-decoration:none;
    color:#e4f3ff;
    margin-left:20px;
    font-size:16px;
    transition:0.2s;
}

.nav-right a:hover {
    color:var(--neon);
}

/* SPORTS GRID */
.grid {
    display:grid;
    grid-template-columns:repeat(auto-fit, minmax(140px, 1fr));
    gap:20px;
    padding:25px;
}

.sport-card {
    background:rgba(255,255,255,0.04);
    padding:30px 15px;
    border-radius:14px;
    text-align:center;
    cursor:pointer;
    transition:0.3s;
    border:1px solid rgba(255,255,255,0.05);
    box-shadow:0 4px 16px rgba(0,0,0,0.35);
}

.sport-card:hover {
    transform:translateY(-5px);
    box-shadow:0 10px 28px rgba(0,0,0,0.5);
    background:rgba(255,255,255,0.07);
}

.icon {
    font-size:40px;
    padding-bottom:8px;
}
</style>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div class="nav-left">
        <h1>👋 Hello, <?= htmlspecialchars($userName) ?></h1>
    </div>

    <div class="nav-right">
        <a href="dashboard.php">🏠 Home</a>
        <a href="profile.php">👤 Profile</a>
        <a href="logout.php" style="color:#ff5555;">🚪 Logout</a>
    </div>
</div>

<h2 style="padding:20px; font-size:26px; text-align:center;">Explore Sports</h2>

<!-- SPORTS GRID -->
<div class="grid">
<?php foreach ($sports as $sport): ?>
    <a href="sport_page.php?sport=<?= $sport[1] ?>" style="text-decoration:none; color:white;">
        <div class="sport-card">
            <div class="icon"><?= $sport[0] ?></div>
            <div><?= $sport[1] ?></div>
        </div>
    </a>
<?php endforeach; ?>
</div>

</body>
</html>
