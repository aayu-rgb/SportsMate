<?php
session_start();
$conn = new mysqli("localhost", "root", "", "sportsmate_db");

$sender = $_SESSION['user_id'];
$receiver = intval($_GET['receiver']);

// Mark received messages as seen
$conn->query("UPDATE messages SET status='seen' 
    WHERE sender_id=$receiver AND receiver_id=$sender");

// Pull chat history
$sql = "
SELECT * FROM messages
WHERE (sender_id=$sender AND receiver_id=$receiver)
   OR (sender_id=$receiver AND receiver_id=$sender)
ORDER BY timestamp ASC
";
$res = $conn->query($sql);

while($m = $res->fetch_assoc()) {

    $class = ($m['sender_id'] == $sender) ? "self" : "";

    $status = "";
    if ($m['sender_id'] == $sender) {
        if ($m['status'] == "sent") $status = "✔";
        if ($m['status'] == "delivered") $status = "✔";
        if ($m['status'] == "seen") $status = "✔✔";
    }

    $msg = htmlspecialchars($m['message']);
    $time = date("h:i A", strtotime($m['timestamp']));

    echo "
    <div class='msg $class'>
        $msg
        <small>$time — $status</small>
    </div>
    ";
}
?>
