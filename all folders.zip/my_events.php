<?php
session_start();
$conn = new mysqli("localhost", "root", "", "sportsmate_db");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$uid = $_SESSION['user_id'];

$query = "
SELECT events.* FROM event_participants 
JOIN events ON event_participants.event_id = events.id
WHERE event_participants.user_id = $uid
";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Joined Events</title>
    <style>
        body {
            background: black;
            color: white;
            font-family: Arial;
            padding: 20px;
        }
        .event-box {
            background: #1f1f1f;
            padding: 15px;
            margin: 15px 0;
            border-radius: 12px;
        }
        a {
            color: #00eaff;
            text-decoration: none;
            font-size: 18px;
        }
        .back {
            display: inline-block;
            margin-top: 20px;
            color: white;
            background: #00eaff;
            padding: 10px 20px;
            border-radius: 8px;
        }
    </style>
</head>
<body>

<h2>My Joined Events</h2>

<?php if ($result->num_rows > 0) { ?>
    <?php while ($row = $result->fetch_assoc()) { ?>
        <div class="event-box">
            <h3><?= $row['title'] ?></h3>
            <p><strong>Sport:</strong> <?= $row['sport'] ?></p>
            <p><strong>Location:</strong> <?= $row['location'] ?></p>
            <p><strong>Date:</strong> <?= $row['event_date'] ?></p>
        </div>
    <?php } ?>
<?php } else { ?>
    <p>You have not joined any events yet 😊</p>
<?php } ?>

<a class="back" href="dashboard.php">⬅ Back to Dashboard</a>

</body>
</html>
