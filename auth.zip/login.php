<?php
session_start();
require 'config.php';

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $query = "SELECT * FROM users WHERE email=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {

        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {

            // ⭐ FIXED SESSION VALUES ⭐
            $_SESSION['user_id']  = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['role'] = $user['role'];

            header("Location: dashboard.php");
            exit;
        } else {
            $message = "❌ Incorrect password.";
        }
    } else {
        $message = "❌ No account found.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Login - SportsMate</title>
<style>
    body {
        background: #0b0f19;
        color: white;
        font-family: Arial, sans-serif;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }
    .card {
        background: #1b2333;
        padding: 25px;
        border-radius: 15px;
        width: 320px;
        box-shadow: 0 0 20px rgba(0,255,200,0.2);
    }
    input {
        width: 100%;
        padding: 12px;
        margin-top: 10px;
        border: none;
        border-radius: 8px;
        outline: none;
    }
    button {
        width: 100%;
        padding: 12px;
        margin-top: 15px;
        border: none;
        background: linear-gradient(to right, #00eaff, #0aff7b);
        color: black;
        font-weight: bold;
        border-radius: 8px;
        cursor: pointer;
        transition: .3s;
    }
    button:hover {
        opacity: .8;
    }
    .alert {
        background: #16202f;
        padding: 10px;
        margin-bottom: 10px;
        border-left: 4px solid #0aff7b;
        border-radius: 5px;
    }
    a {
        color: #42faff;
    }
</style>
</head>
<body>

<div class="card">
    <h2>🔐 Login</h2>

    <?php if ($message): ?>
        <div class="alert"><?= $message ?></div>
    <?php endif; ?>

    <form action="" method="POST">
        <input type="email" name="email" placeholder="Email" required />
        <input type="password" name="password" placeholder="Password" required />
        <button type="submit">Login</button>
    </form>

    <p style="margin-top: 10px;">
        Don't have an account? <a href="register.php">Register</a>
    </p>
</div>

</body>
</html>
