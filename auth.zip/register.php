<?php
session_start();
require 'config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: home.php');
    exit;
}

$name  = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$pass  = trim($_POST['password'] ?? '');

if (!$name || !$email || !$pass) {
    header('Location: login.php?reg=err&msg=missing');
    exit;
}

// Check if email exists
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->close();
    header('Location: login.php?reg=err&msg=exists');
    exit;
}
$stmt->close();

// Hash password and create user
$hash = password_hash($pass, PASSWORD_DEFAULT);
$role = 'user';

$stmt = $conn->prepare("
    INSERT INTO users (name, email, phone, password, role, created_at)
    VALUES (?, ?, ?, ?, ?, NOW())
");
$stmt->bind_param("sssss", $name, $email, $phone, $hash, $role);

if ($stmt->execute()) {
    $stmt->close();
    header('Location: login.php?reg=ok'); // ⭐ SUCCESS → direct to login page
    exit;
} else {
    $stmt->close();
    header('Location: login.php?reg=err&msg=db');
    exit;
}
?>
